const speakeasy = require('speakeasy');
const nodemailer = require('nodemailer');
const CardPayment = require('../models/cardDetails');

exports.getCardPayments = async (req, res) => {
    try {
        const cardpayments = await CardPayment.find().populate('payment');
        res.json(cardpayments);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

exports.addCardPayment = async (req, res) => {
    try {
        const newCardPayment = new CardPayment({
            nameOnCard: req.body.nameOnCard,
            cardNumber: req.body.cardNumber,
            expDate: req.body.expDate,
            cvv: req.body.cvv,
            payment: req.body.payment,
        });

        const otp = generateOTP();

        console.log("OTP",otp);

        
        const cardPayment = await newCardPayment.save();
        res.json(cardPayment);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

exports.deleteCardPayment = async (req, res) => {
    try {
        const deletedCardPayment = await CardPayment.findByIdAndDelete(req.params.id);
        if (!deletedCardPayment) {
            return res.status(404).json({ msg: 'Card Payment not found' });
        }
        res.json({ msg: 'Payment removed', deletedCardPayment });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};


//new


exports.getCardPaymentById = async (req, res) => {
    try {
        const cardPayment = await CardPayment.findById(req.params.id).populate('payment');
        if (!cardPayment) {
            return res.status(404).json({ msg: 'Card Payment not found' });
        }
        res.json(cardPayment);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

exports.editCardPayment = async (req, res) => {
    try {
        const updatedCardPayment = await CardPayment.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedCardPayment) {
            return res.status(404).json({ msg: 'Card Payment not found' });
        }
        res.json(updatedCardPayment);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

//OTP



// Generate a new secret and OTP URI
function generateOTP() {
    const secret = speakeasy.generateSecret({ length: 10 }); // 10 bytes will be equivalent to 80 bits
    const otp = generateTOTP(secret.ascii);
    
    return {
        secret: secret.ascii,
        otp
    };
}

// // Generate OTP based on secret
// function generateTOTP(secret) {
//     return speakeasy.totp({
//         secret: secret,
//         encoding: 'ascii',
//         digits: 6 // Set to 6 digits
//     });
// }

// // Send OTP via email
// async function sendOTPByEmail(email, otp) {
//     // Create a SMTP transporter
//     let transporter = nodemailer.createTransport({
//         service: 'gmail',
//         auth: {
//             user: 'your_email@gmail.com', // Enter your email
//             pass: 'your_password' // Enter your password
//         }
//     });

//     // Setup email data
//     let mailOptions = {
//         from: 'your_email@gmail.com', // Enter sender email
//         to: email, // Enter receiver email
//         subject: 'Your OTP', // Email subject
//         text: `Your OTP is: ${otp}` // Email body
//     };

//     // Send email
//     let info = await transporter.sendMail(mailOptions);

//     console.log('Message sent: %s', info.messageId);
// }

// Example usage
// const { secret, otp } = generateOTP();
// console.log('Generated OTP:', otp);

// // Send OTP via email
// const email = 'recipient@example.com'; // Replace with recipient's email
// sendOTPByEmail(email, otp)
//     .then(() => console.log('OTP sent via email.'))
//     .catch(error => console.error('Error sending email:', error));
